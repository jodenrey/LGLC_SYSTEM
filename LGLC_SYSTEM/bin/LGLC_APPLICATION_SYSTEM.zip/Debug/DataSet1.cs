﻿namespace LGLC_SYSTEM
{


    public partial class DataSet1
    {
    }
}
namespace LGLC_SYSTEM {
    
    
    public partial class DataSet1 {
    }
}
